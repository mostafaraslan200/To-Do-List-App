

class ToDo {
  String? id;
  String? todoText;
  bool isDone;
  DateTime? time;

  ToDo({
    required this.id,
    required this.todoText,
    this.isDone = false,
    this.time,
  });



  // Method to format the time with AM/PM



}